import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgxPaginationModule} from 'ngx-pagination';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './Components/user/user.component';
import { HomeComponent } from './Components/home/home.component';
import { CreateUserComponent } from './Components/create-user/create-user.component';
import { UserLoginComponent } from './Components/user-login/user-login.component';
import { TestComponent } from './Components/test/test.component';
import { CreateAdminComponent } from './Components/create-admin/create-admin.component';
import { AdminLoginComponent } from './Components/admin-login/admin-login.component';
import { AdminComponent } from './Components/admin/admin.component';
import { UserListComponent } from './Components/user-list/user-list.component';
import { QuestionsComponent } from './Components/questions/questions.component';
import { TestListComponent } from './Components/test-list/test-list.component';
import { CreateTestComponent } from './Components/create-test/create-test.component';
import { CreateQuestionComponent } from './Components/create-question/create-question.component';
import { HomepageComponent } from './Components/homepage/homepage.component';
import { MaterialModule } from './material/MaterialModule';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    HomeComponent,
    CreateUserComponent,
    UserLoginComponent,
    TestComponent,
    CreateAdminComponent,
    AdminLoginComponent,
    AdminComponent,
    UserListComponent,
    QuestionsComponent,
    TestListComponent,
    CreateTestComponent,
    CreateQuestionComponent,
    HomepageComponent,

  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
