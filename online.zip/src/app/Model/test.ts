export class Test {
    test_id:number
    noOfQuestions:number
}
