export class Admin {
    name:string
    emailId:string
    password:string
}
