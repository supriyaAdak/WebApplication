export class User {
    userId:number
    userName:string
    userEmail:string
    password:string
    test:string
}
