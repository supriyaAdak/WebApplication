import { Component, OnInit } from '@angular/core';
import { UserServiceService } from 'src/app/Service/user-service.service';
import { User } from 'src/app/Model/user';
import { Router } from '@angular/router';
import { Login } from 'src/app/Model/login';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.scss']
})
export class UserLoginComponent implements OnInit {


  userCheck: User;
  login:Login;
 // user: User;
  loginCheck: User[];
  userEmail: any;
  password: any;
  constructor(private router: Router, private service:UserServiceService) {
    this.login = new Login();
    this.userEmail = this.login.email;
    this.password = this.login.password;
  }

  ngOnInit() {
  }


  userLogin() {
    this.service.userLogin(this.login).subscribe(res => {
       localStorage.setItem('token', res.headers.get('token'));
      console.log(res.headers.get('token'));
      if (localStorage.getItem('token') != null) {
        this.router.navigate(['/user']);
        alert('Login Sucessfully')
      }
    }, (error) => {console.error(error),
      alert('Invalid User')});
  }
  logOut(){
    localStorage.removeItem('token');
    this.router.navigate(['/home']);
  }
      }

 
  

