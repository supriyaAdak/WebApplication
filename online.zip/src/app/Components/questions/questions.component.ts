import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/Model/question';
import { AdminService } from 'src/app/Service/admin.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.sass']
})
export class QuestionsComponent implements OnInit {

  questions: Observable<Question[]>;
  constructor(private service:AdminService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.questions = this.service.questionList();
   
  }
  deleteQuestion(questionId:number){
    this.service.deleteQuestion(questionId).subscribe(data => {
      console.log(data);
      this.reloadData();
    },error => console.log(error));
}
}
