import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/Service/admin.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-create-admin',
  templateUrl: './create-admin.component.html',
  styleUrls: ['./create-admin.component.scss']
})
export class CreateAdminComponent implements OnInit {
  
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private service:AdminService,
    private router:Router) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
        //  userName:[]', Validators.required],
         name:['',[Validators.required]],
        emailId: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required, Validators.minLength(6)]],
         
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }
  save(){
    this.service.createAdmin(this.registerForm.value)
    .subscribe(data => console.log(data), error => console.log(error));
 
  }
  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.registerForm.valid) {
        // this.service.createUser(this.registerForm.value);
        this.save();
        alert('SUCESS!! :-)');
        this.router.navigate(['/adminLogin']);
      }
      else{alert('Fail!! :-(');}
      //  
      //  \n\n' + JSON.stringify(this.registerForm.value))
  }
}



//   admin: Admin = new Admin();
//   adminForm: FormGroup;
//   loading = false;
//   submitted = false;
//   constructor(private router: Router, private service: AdminService) { }

//   ngOnInit() {
//   }

//   newAdmin(): void {
//     this.submitted = false;
//     this.admin = new Admin();
//   }

//   onSubmit() {
//     this.submitted = true;
//     this.save();
//   }

//   save() {
//     this.service.createAdmin(this.admin).subscribe(data => console.log(data), error => console.log(error));
//     this.admin = new Admin();
//     this.router.navigate(['/adminLogin'])
//   }
// }
