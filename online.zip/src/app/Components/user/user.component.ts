import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from 'src/app/Service/user-service.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  constructor(private router:Router,private service:UserServiceService) { }

  ngOnInit() {
  }
  takeTest(){
    console.log("test");
    
   // this.service.takeTest().subscribe(res =>)
   this.router.navigate(['/test']);

  }
  logOut(){
    localStorage.removeItem('token');
    this.router.navigate(['/home']);
  }

}
