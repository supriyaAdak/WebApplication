import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss']
})
export class HomepageComponent implements OnInit {

  config: any;
  questions:Array<any>[];
  collection = { count: 60, data: [] };
 
  constructor( private service:AdminService,private router:Router) {
 
    //Create dummy data
    for (var i = 0; i < this.collection.count; i++) {
      this.collection.data.push(
        {
          id: i + 1,
          value: "items number " + (i + 1)
        }
      );
    }
 
    this.config = {
      itemsPerPage: 1,
      currentPage: 1,
      totalItems: this.questions
    };
  }
 
  pageChanged(event){
    this.config.currentPage = event;
  }
  getQuestions(){
    this.service.getTest(2).subscribe(res=> this.questions)
  }
  ngOnInit(){}
 
}