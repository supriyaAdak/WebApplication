import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/Model/question';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-create-question',
  templateUrl: './create-question.component.html',
  styleUrls: ['./create-question.component.sass']
})
export class CreateQuestionComponent implements OnInit {
  question: Question = new Question();
  loading = false;
  submitted = false;
  constructor(private router: Router, private service: AdminService) { }

  ngOnInit() {
  }

  newQuestion(): void {
    this.submitted = false;
    this.question= new Question();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

  save() {
    this.service.createQuestion(this.question).subscribe(data => console.log(data), error => console.log(error));
    this.question= new Question();
  }
}

