import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';
import { Question } from 'src/app/Model/question';
import { Observable } from 'rxjs';
import { UserServiceService } from 'src/app/Service/user-service.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.sass']
})
export class TestComponent implements OnInit {
  //questions: Observable<Question[]>;
   questions:any;
   config: any;
  // questionsList:Question[];
  form:FormGroup;
  constructor(private router:Router, private service :AdminService,private userService:UserServiceService, private formBuilder: FormBuilder) {
    this.config = {
      itemsPerPage: 1,
      currentPage: 1,
      totalItems: this.questions    };
      formBuilder
   }

  ngOnInit() {
    this.loadData();
  }
loadData(){
  console.log("list");
  // this.questions=this.service.getTest(1);
   this.userService.takeTest().subscribe(res => {this.questions=res;
    console.log(this.questions);
  //  var result = Object.keys(obj).map(function(key) {
  //   return [Number(key), obj[key]];
  // });
  // const mapped = Object.keys(obj).map(key => ({type: key, value: obj[key]}));
  console.log("abc")
  if(this.questions!=null){
  const mapped = Object.keys(this.questions).map(key => ({type: key, value: this.questions[key]}));
  console.log(mapped);
 
  }
  else{
    alert("No Test Found For This User!!!")
    this.router.navigate(['/user']);
  }
}, (error) => console.error("No Test Found"));

}
pageChanged(event){
  this.config.currentPage = event;
}

}
