import { Component, OnInit } from '@angular/core';
import { UserServiceService } from 'src/app/Service/user-service.service';
import { User } from 'src/app/Model/user';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,private service:UserServiceService,
    private router:Router) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          userName: ['', Validators.required],
         
          userEmail: ['', [Validators.required, Validators.email]],
          password: ['', [Validators.required, Validators.minLength(6)]],
         
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }
  save(){
    this.service.createUser(this.registerForm.value)
    .subscribe(data => console.log(data), error => console.log(error));
 
  }
  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.registerForm.valid) {
        // this.service.createUser(this.registerForm.value);
        this.save();
        alert('SUCESS!! :-)');
        this.router.navigate(['/userLogin']);
      }
      else{alert('Fail!! :-(');}
      //  
      //  \n\n' + JSON.stringify(this.registerForm.value))
  }
}
//   user: User=new User();
//   constructor(private service:UserServiceService,private router :Router) { }
//   submitted = false;
//   ngOnInit() {
    
//   }
//   get f() { return this.user; }

//   save(){
//     this.service.createUser(this.user)
//     .subscribe(data => console.log(data), error => console.log(error));
 
//   }
//   onSubmit() {
//     this.submitted = true;
//     this.save();   
//     this.router.navigate(['/userLogin'])
//   }
// }

