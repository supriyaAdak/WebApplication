import { Component, OnInit } from '@angular/core';
import { Test } from 'src/app/Model/test';
import { Observable } from 'rxjs';
import { AdminService } from 'src/app/Service/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-test-list',
  templateUrl: './test-list.component.html',
  styleUrls: ['./test-list.component.sass']
})
export class TestListComponent implements OnInit {
  tests: Observable<Test[]>;
  constructor(private service:AdminService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.tests = this.service.testList();
    console.log(this.tests)
   
  }
  deleteTest(testId:number){
    this.service.deleteTest(testId).subscribe(data => {
      console.log(data);
      this.reloadData();
    },error => console.log(error));
    
  }
     
}

