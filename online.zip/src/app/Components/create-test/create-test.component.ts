import { Component, OnInit } from '@angular/core';
import { Test } from 'src/app/Model/test';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/Service/admin.service';

@Component({
  selector: 'app-create-test',
  templateUrl: './create-test.component.html',
  styleUrls: ['./create-test.component.scss']
})
export class CreateTestComponent implements OnInit {
  test:Test=new Test();
  loading = false;
  submitted = false;
  constructor(private router: Router, private service: AdminService) { }

  ngOnInit() {
  }
  newAdmin(): void {
    this.submitted = false;
    this.test = new Test();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

  save() {
    this.service.createTest(this.test).subscribe(data => console.log(data), error => console.log(error));
    this.test = new Test();
  }
}
