import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { User } from 'src/app/Model/user';
import { UserServiceService } from 'src/app/Service/user-service.service';
import { AdminService } from 'src/app/Service/admin.service';
import { Test } from 'src/app/Model/test';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.sass']
})
export class UserListComponent implements OnInit {

 testId;
 result;
  tests:Observable<Test[]>;

  test2:Array<any>;
  
  users: Observable<User[]>;

  constructor(private service:UserServiceService,
    private adminService:AdminService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
    this.testList();
  }

  reloadData() {
    this.users = this.service.userList();
   
  }

  assignTest(userId:number,event:any){
    console.log(userId)
    this.testId = event.target.value;
    console.log(this.testId);
    this.adminService.assignTest(userId,this.testId).subscribe(res=>{this.result=res,
      this.reloadData()});
    
   }
   //event handler for the select element's change event
   selectChangeHandler (event: any) {
    //update the ui
    this.testId = event.target.value;
    console.log(this.testId);
  
  }
  testList(){
    this.adminService.testList().subscribe(data=>{
      console.log(data);
      this.test2=data});
     console.log("Admin"+this.tests);
//      <!-- <select (change)="($event.item.testId)">
//      <option  value="0">--All--</option>
//      <option *ngFor="let item of tests" value={{item.testId}}>
//          {{item.testId}}
//      </option>
//  </select> -->
   
  }
}


 






