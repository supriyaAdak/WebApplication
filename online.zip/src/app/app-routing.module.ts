import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { CreateUserComponent } from './Components/create-user/create-user.component';
import { TestComponent } from './Components/test/test.component';
import { CreateAdminComponent } from './Components/create-admin/create-admin.component';
import { UserLoginComponent } from './Components/user-login/user-login.component';
import { AdminLoginComponent } from './Components/admin-login/admin-login.component';
import { UserComponent } from './Components/user/user.component';
import { AdminComponent } from './Components/admin/admin.component';
import { UserListComponent } from './Components/user-list/user-list.component';
import { QuestionsComponent } from './Components/questions/questions.component';
import { TestListComponent } from './Components/test-list/test-list.component';
import { CreateTestComponent } from './Components/create-test/create-test.component';
import { CreateQuestionComponent } from './Components/create-question/create-question.component';
import { HomepageComponent } from './Components/homepage/homepage.component';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'createUser', component: CreateUserComponent },
  { path: 'test' , component: TestComponent},
  { path: 'createAdmin', component:CreateAdminComponent},
  { path: 'userLogin', component:UserLoginComponent},
  { path: 'adminLogin', component:AdminLoginComponent},
  { path: 'user', component:UserComponent},
  { path: 'admin', component:AdminComponent},
  { path: 'userList', component:UserListComponent},
  { path: 'questionList', component:QuestionsComponent},
  {path: 'testList', component:TestListComponent},
  {path:'createTest', component: CreateTestComponent},
  {path: 'createQuestion', component:CreateQuestionComponent},
  { path:'homepage', component:HomepageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
