import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../Model/user';
import { Observable } from 'rxjs';
import { Login } from '../Model/login';
import { Question } from '../Model/question';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  private baseUrl = 'http://localhost:8293/user';
  constructor(private http:HttpClient) { }
  private httpheaders = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      token: localStorage.getItem('token')
    })
  };

  createUser(user:User){
    return this.http.post(this.baseUrl+'/create',user)
  }

  userLogin(login:Login):Observable<any>{
    return this.http.post<any>(this.baseUrl+'/login',login,{observe:'response'});
  }
  userList() : Observable<User[]>{
    return this.http.get<User[]>(this.baseUrl+'/getAll')
  }
  takeTest():Observable<Question[]>{
    return this.http.get<Question[]>(this.baseUrl+'/test',this.httpheaders);
  }
}
